const version = "1.4.11";

export default version;
